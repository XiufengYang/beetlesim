function dx = odefun8(t, x, xhis, paras)

dx = zeros(6,1);

g = 9.81;

m1 = paras(1);
m2 = paras(2);
J1 = paras(3);
J2 = paras(4);
l1 = paras(5);
l2 = paras(6);

c1 = paras(7);
c2 = paras(8);
gamma1 = paras(9);
gamma2 = paras(10);
Tps = paras(11:18);

[theta, dtheta, ddtheta] = thetaf(t, Tps);
[l0, dl0, ddl0] = l0f(l1, l2, theta, dtheta, ddtheta);
[phi1, dphi1, ddphi1] = phi1f(l1, l2, l0, dl0, ddl0, theta, dtheta, ddtheta);
[phi2, dphi2, ddphi2] = phi2f(l1, l2, l0, dl0, ddl0, theta, dtheta, ddtheta);

dx(1) = x(2);
dx(2) = xhis(2);

x2 = x(1);
dx2 = x(2);
ddx2 = xhis(2);

f1 = xhis(3);
f2 = xhis(4);

for i = 1:1
    
x0 = x2 + l0;
dx0 = dx2 + dl0;
ddx0 = ddx2 + ddl0;

X1 = x0 - c1*cos(phi1 + gamma1);
X2 = x2 + c2*cos(phi2 + gamma2);

ddX1 = ddx0 + c1*cos(phi1 + gamma1)*ddphi1^2 + c1*sin(phi1 + gamma1)*ddphi1;
ddX2 = ddx2 - c2*cos(phi2 + gamma2)*ddphi2^2 - c2*sin(phi2 + gamma2)*ddphi2;

Y1 = c1*sin(phi1 + gamma1);
Y2 = c2*sin(phi2 + gamma2);

ddY1 = -c1*sin(phi1+gamma1)*dphi1^2 + c1*cos(phi1+gamma1)*ddphi1;
ddY2 = -c2*sin(phi2+gamma2)*dphi2^2 + c2*cos(phi2+gamma2)*ddphi2;

% fn1 = (-J1*ddphi1 + J2*ddphi2 + (m1+m2)*g*(X2-x2) - m1*ddX1*Y1 - m2*ddX2*Y2 - m1*ddY1*(x2-X1) - m2*ddY2*(x2-X2))/l0;
% fn2 = ( J1*ddphi1 - J2*ddphi2 + (m1+m2)*g*(x0-X2) + m1*ddX1*Y1 + m2*ddX2*Y2 + m1*ddY1*(x0-X1) + m2*ddY2*(x0-X2))/l0;

fn1 = (-J1*ddphi1 + J2*ddphi2 - m1*ddX1*Y1 - m2*ddX2*Y2 + m1*(g+ddY1)*(X1-x2) + m2*(g+ddY2)*(X2-x2))/l0;
fn2 = ( J1*ddphi1 - J2*ddphi2 + m1*ddX1*Y1 + m2*ddX2*Y2 + m1*(g+ddY1)*(x0-X1) + m2*(g+ddY2)*(x0-X2))/l0;

if ( fn1 < 0)
   
    fn1 = 0;
    
    fn2 = (m1+m2)*g + (m1*ddY1 + m2*ddY2);
    
end

if (fn2 < 0)
   
    fn2 = 0;
    
    fn1 = (m1+m2)*g + (m1*ddY1 + m2*ddY2);
    
end

f1t = m1*ddX1 + m2*ddX2 - f2;
f2t = m1*ddX1 + m2*ddX2 - f1;

[mu1, mu2] = muf(dx0, dx2);

if (abs(dx0)<1e-6)
    
    if ((mu1*fn1 >= f1t) &&(f1t >=0))
    
        f1 = f1t;
    
    elseif ((mu1*fn1 <= f1t)&&(f1t<0))
        
        f1 = f1t;
    
    else
        
        f1 = mu1*fn1;
        
    end
    
else
    
    f1 = mu1*fn1;
      
end

if (abs(dx2)<1e-6)
    
    if((mu2*fn2 >= f2t) && (f2t >= 0))
    
        f2 = f2t;
        
    elseif ((mu2*fn2 < f2t) && (f2t < 0))
    
        f2 = f2t;
        
    else
        
        f2 = mu2*fn2;
        
    end
    
else
    
    f2 = mu2*fn2;
      
end

dx(1) = dx2;
dx(2) = (f1 + f2 - m1*(ddl0 + c1*cos(phi1+gamma1)*dphi1^2 + c1*sin(phi1+gamma1)*ddphi1) + m2*(c2*cos(phi2+gamma2)*dphi2^2 + c2*sin(phi2+gamma2)*ddphi2))/(m1+m2);

dx2 = dx(1);
ddx2 = dx(2);

dx(3:13) = [f1; f2; fn1; fn2; X1; X2; x0; phi1; phi2; m1*ddX2; m2*ddX1];

end


end