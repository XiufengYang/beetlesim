function [l0, dl0, ddl0] = l0f(l1, l2, theta, dtheta, ddtheta)

    l0 = sqrt(l1^2 + l2^2 - 2*l1*l2*cos(theta));
    
    dl0 = l1*l2*sin(theta)*dtheta/l0;
    
    ddl0 = (l1*l2*cos(theta)*dtheta^2 + l1*l2*sin(theta)*ddtheta -dl0^2)/l0;

end