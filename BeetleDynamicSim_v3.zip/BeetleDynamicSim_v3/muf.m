function [mu1, mu2] = muf(dx1, dx2)

if (dx1 > 0)
    
    mu1 = -1.0872;
    
else

    mu1 = 8.7575;
    
end

if (dx2 > 0)
    
    mu2 = -0.8012;
    
else

    mu2 = 1.955;
   
end


end

% function [mu1, mu2] = muf(dx1, dx2)
% 
% if (dx1 > 0)
%     
%    mu1 = -0.6561;
%     
% else
%     
%    mu1 = 3.638;
%     
% end
% 
% if (dx2 > 0)
%     
%   mu2 = -0.6457;
%     
% else
%     
%    mu2 = 1.09;
%    
% end
% 
% end