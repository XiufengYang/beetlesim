function [phi2, dphi2, ddphi2] = phi2f(l1, l2, l0, dl0, ddl0, theta, dtheta, ddtheta)

phi2 = asin(l1/l0*sin(theta));

dphi2 = (l1*cos(theta)*dtheta - dl0*sin(phi2))/(l0*cos(phi2));

ddphi2 = (l1*(-sin(theta)*dtheta^2 + cos(theta)*ddtheta) - ddl0*sin(phi2) - 2*dl0*cos(phi2)*dphi2 + l0*sin(phi2)*dphi2^2)/(l0*cos(phi2));

end