1. Run the script DynSim.m 

2. The simulation is running with a very small time step size. It takes approximately 6 hours with Matlab 2018b on Windows 10 and Intel i7-8750U. Also, please ensure your RAM is at least 16GB.