function [theta, dtheta, ddtheta] = thetaf(t, Tps)

    T = Tps(1);
    T1 = Tps(2);
    T2 = Tps(3); %heating
    T3 = Tps(4);
    T4 = Tps(5); %cooling
    
    theta0 = Tps(6);    
    theta_amp = Tps(7);  
	ts = Tps(8); % initial cycle shifting for compariswon with experiment data
    
    tt = mod(t+ts,T);
    if (tt <= T1)
        
        theta = theta0;
        dtheta = 0;
        ddtheta = 0;
        
    elseif ((tt <= T1+T2) && (tt > T1))
        
        Ts = T1;
        Tc = 2*T2;
        
        theta = theta0 - theta_amp/2*cos(2*pi/Tc*(tt-Ts)) + theta_amp/2.0; 
        dtheta = theta_amp/2*(2*pi/Tc)*sin(2*pi/Tc*(tt-Ts));
        ddtheta = theta_amp/2*(2*pi/Tc)^2*cos(2*pi/Tc*(tt-Ts));
      
    elseif ((tt <= T1+T2+T3) && (tt > T1+T2))
        
        theta = theta0 + theta_amp;
        dtheta = 0;
        ddtheta = 0;
        
    else
       
        Ts = T1 + T2 + T3;
        Tc = 2*T4;
        
        theta = theta0 + theta_amp/2*cos(2*pi/Tc*(tt-Ts)) + theta_amp/2.0; 
        dtheta = -theta_amp/2*(2*pi/Tc)*sin(2*pi/Tc*(tt-Ts));
        ddtheta = -theta_amp/2*(2*pi/Tc)^2*cos(2*pi/Tc*(tt-Ts));

    end

end

