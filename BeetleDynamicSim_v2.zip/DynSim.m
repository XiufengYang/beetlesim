%% clean up
clear all
close all
clc
%% running notes

% The simulation is running with a very small time step size. It takes approximately 6 hours
% with Matlab 2018b on Windows 10 and Intel i7-8750U. Also, please ensure your RAM is at least 16GB.

%% common parameters

g = 9.81;
m1 = 6.8e-6; % unit kg
m2 = 99.1e-6;
J1 = 33.6e-12; % unit kg*m^3
J2 = 2745.7e-12;
l1 = 7.0e-3; % unit m
l2 = 14.1e-3;

c1 = 5.85e-3;
gamma1 = 7.5/180*pi;
c2 = 7.6e-3;
gamma2 = 11.1/180*pi;

dt = 0.000001;

x0 = [0; 0];
xhis0 = zeros(6, 1);

xhis0(3) = 0;
xhis0(4) = 0;
xhis0(5) = (m1+m2)*g/2;
xhis0(6) = (m1+m2)*g/2;

%% dynamic simulations for Fig. 5C

disp('Running simulation for experiment in Fig. 5A. Approximately take 4 hours');

% simulation for crawling experiment in Fig. 5A

Tps1 = [3.4; 0.4; 0.9; 1.2; 0.9; 64.0/180*pi; 10.0/180*pi; 0.0];

paras1 = [m1; m2; J1; J2; l1; l2; c1; c2; gamma1; gamma2; Tps1];

tspan1 = [0, 190.5];

[x,t, xc] = ode4f(@odefun, tspan1, dt, x0, xhis0, paras1);

data_passive.t = t;
data_passive.x = x;
data_passive.xc = xc;

clear t x xc

% simulation for crawling experiment in Fig. 5B

disp('Running simulation for experiment in Fig. 5B. Approximately take 2 hours');

Tps2 = [4.0; 0.8; 1.2; 1.0; 1.0; 46.5/180*pi; 28.0/180*pi; 1.8];

paras2 = [m1; m2; J1; J2; l1; l2; c1; c2; gamma1; gamma2; Tps2];

tspan2 = [0, 99];

[x,t, xc] = ode4f(@odefun, tspan2, dt, x0, xhis0, paras2);

data_active.t = t;
data_active.x = x;
data_active.xc = xc;

clear t x xc

% results post-process for Fig. 5C

t_sim_passive = 0:0.02:190;
t_sim_active = 0:0.02:97;

xc_sim_active = interp1(data_active.t, data_active.xc-data_active.xc(1), t_sim_active)*1000;
xc_sim_passive = interp1(data_passive.t, data_passive.xc-data_passive.xc(1), t_sim_passive)*1000;

data_exp_passive = load('data_exp_passive.mat');
data_exp_active = load('data_exp_active.mat');

t1 = data_exp_passive.t;
x1c = data_exp_passive.x;
x1c = x1c-x1c(1);

t2 = data_exp_active.t;
x2c = data_exp_active.x;
x2c = x2c-x2c(1);

d = designfilt('lowpassiir','FilterOrder',16, 'HalfPowerFrequency',0.16,'DesignMethod','butter');
x1f = filtfilt(d,x1c);
x2f = filtfilt(d,x2c);

% results plot for Fig. 5C

c01 = [238, 29, 37]/255;
c02 = [36, 32, 33]/255;
c03 = [20, 94, 171]/255;
c04 = [86, 185, 71]/255;

fig0 = figure('Units','points','Position',[300 300 280 152]);
plot(t1,x1f,'LineWidth',1.0, 'Color', c01);
hold on
plot(t_sim_passive, xc_sim_passive, 'LineWidth', 0.5, 'Color', c02);
plot(t2, x2f, 'LineWidth',1.0, 'Color', c03);
plot(t_sim_active, xc_sim_active, 'LineWidth', 0.5, 'Color', c04);

xlabel('Time (s)');
ylabel('Position (mm)');
ylim([-1 80]);
yticks([0 20 40 60 80]);
leg=legend('Crawling experiment(Fig. 5A)','Crawling simulation(Fig. 5A)',...
    'Crawling experiment(Fig. 5B)', 'Crawling simulation(Fig. 5B)', 'Location', 'southeast');
leg.ItemTokenSize=[25,25,25,25];
legend boxoff

set(gca,'FontName','Myriad Pro','FontSize',8);

print(fig0,'Fig5C','-dsvg');

%% dynamic simulation for Fig. S7

disp('Running simulation for Fig. S7. Approximately take 10 mins');

Tps3 = [4.0; 0.8; 1.2; 1.0; 1.0; 46.5/180*pi; 28.0/180*pi; 0.0];

paras3 = [m1; m2; J1; J2; l1; l2; c1; c2; gamma1; gamma2; Tps3];

tspan3 = [0, 8];

[x, t, xc, f1, f2, fn1, fn2, x0, phi1, phi2] = ode4f(@odefun, tspan3, dt, x0, xhis0, paras3);

% results post-process

t_sim = 0:0.001:8;

x0_sim = interp1(t, x0, t_sim)*1000;
x2_sim = interp1(t, x(:,1), t_sim)*1000;

phi1_sim = interp1(t, phi1, t_sim);
phi2_sim = interp1(t, phi2, t_sim);

d = designfilt('lowpassiir','FilterOrder',12, 'HalfPowerFrequency',0.0001,'DesignMethod','butter');

ft1 = filtfilt(d, f1);
ft2 = filtfilt(d, f2);

fnt1 = filtfilt(d, fn1);
fnt2 = filtfilt(d, fn2);

f1_sim = interp1(t, ft1, t_sim);
f2_sim = interp1(t, ft2, t_sim);

fn1_sim = interp1(t, fnt1, t_sim);
fn2_sim = interp1(t, fnt2, t_sim);

% result plots for Fig. S7

fig1 = figure('Units','points','Position',[300 300 280 154]);

plot(t_sim, x0_sim, 'LineWidth',0.5);

hold  on

plot(t_sim, x2_sim, 'LineWidth',0.5);

xlabel('Time (s)');
ylabel('Position (mm)');
title('Positions of point P_0 and P_2', 'FontWeight', 'Normal');

xlim([0, 8]);
ylim([-5, 20]);
legend('x_0','x_2', 'Location', 'best');
legend boxoff

set(gca,'FontName','Myriad Pro','FontSize',8);

print(fig1,'FigS7A','-dsvg');

%%%%

fig2 = figure('Units','points','Position',[300 300 280 152]);

plot(t_sim, phi1_sim, 'LineWidth',0.5);

hold  on

plot(t_sim, phi2_sim, 'LineWidth',0.5);

xlabel('Time (s)');
ylabel('Angle (rad)');
title('Inclinded angles of linkages', 'FontWeight', 'Normal');

xlim([0, 8]);
ylim([0, 2]);
legend('\phi_1','\phi_2','Location', 'east');
legend boxoff

set(gca,'FontName','Myriad Pro','FontSize',8);

print(fig2,'FigS7B','-dsvg');

%%%%

fig3 = figure('Units','points','Position',[300 300 634 158]);

plot(t_sim, f2_sim*1000, 'LineWidth',0.5);

hold  on

plot(t_sim, fn2_sim*1000, 'LineWidth',0.5);

xlabel('Time (s)');
ylabel('Force (mN)');
title('Friction and normal forces at P_2', 'FontWeight', 'Normal');

xlim([0, 8]);
ylim([-0.6, 0.9]);
yticks([-0.5 0 0.5]);
legend('f_2','f_{n2}','Location', 'best');
legend boxoff

set(gca,'FontName','Myriad Pro','FontSize',8);

print(fig3,'FigS7C','-dsvg');

% % save simulation data
% 
% out = input('Please input 1 for saving the intermediate simulation data, 0 for exiting directly\n');
% 
% if out == 1
% 
% 	save('data_sim_active1', 'data_active');
% 	save('data_sim_passive1', 'data_passive');
% 
% end
