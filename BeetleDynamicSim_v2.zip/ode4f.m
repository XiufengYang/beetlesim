function [y, t, xc2, f1, f2, fn1, fn2, x0, phi1, phi2, mx1, mx2] = ode4f(f,tspan,dt,y0,xhis,varargin)

yi = y0;

y = [];
t = [];
xc2 = [];
x0 = [];
phi1 = [];
phi2 = [];
f1 = [];
f2 = [];
fn1 = [];
fn2 = [];
mx1 = [];
mx2 = [];

if (nargin > 4)
    
    for ti = tspan(1):dt:tspan(2)
        
        for i = 1:1
            
        x = feval(f,ti,yi,xhis,varargin{:}); % if varargin used instead of varargin{:}, it will recognize as one argument
        
        k1 = dt*x(1:2);
        xhis1 = x;
        
        x = feval(f,ti+dt/2.0,yi+k1/2.0,xhis1, varargin{:});
        
        k2 = dt*x(1:2);
        xhis2 = x;
        
        x = feval(f,ti+dt/2.0,yi+k2/2.0,xhis2, varargin{:});
        
        k3 = dt*x(1:2);
        xhis3 = x;
        
        x = feval(f,ti+dt,yi+k3,xhis3,varargin{:});
        
        k4 = dt*x(1:2);
        xhis4 = x;
        
        yi = yi + (k1+2*k2+2*k3+k4)/6;
        xhis = (xhis1+2*xhis2+2*xhis3+xhis4)/6;
        
        end 
        
        y = [y,yi];
        
        t = [t,ti];
        
        f1 = [f1, xhis(3)];
        f2 = [f2, xhis(4)];
        fn1 = [fn1, xhis(5)];
        fn2 = [fn2, xhis(6)];
        xc2 = [xc2, xhis(8)];
        x0 = [x0, xhis(9)];
        phi1 = [phi1, xhis(10)];
        phi2 = [phi2, xhis(11)];
        mx1 = [mx1, xhis(12)];
        mx2 = [mx2, xhis(13)];
        
    end
    
else
    
end

t = t';
y = y';

end

