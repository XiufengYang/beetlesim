function [phi1, dphi1, ddphi1] = phi1f(l1, l2, l0, dl0, ddl0, theta, dtheta, ddtheta)

phi1 = acos((l1*l1 + l0*l0 - l2*l2)/(2*l1*l0));

dphi1 = (l1*dl0*cos(phi1)-l0*dl0)/(l1*l0*sin(phi1));

ddphi1 = (ddl0*l1*cos(phi1)-2*dl0*l1*sin(phi1)*dphi1-l0*l1*cos(phi1)*dphi1^2-dl0*dl0-l0*ddl0)/(l0*l1*sin(phi1));

end